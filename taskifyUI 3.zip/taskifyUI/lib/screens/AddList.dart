import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:flutter/material.dart';
import '../nav_bar.dart';
import 'AddTask.dart';
import 'package:taskify/util.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import 'package:cool_alert/cool_alert.dart';
import 'package:get/get.dart';
import 'package:taskify/firebase_options.dart';
import 'package:firebase_auth/firebase_auth.dart';

////////////////////////////// 257
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(AddList());
}

class AddList extends StatefulWidget {
  const AddList({Key? key}) : super(key: key);

  @override
  _AddList createState() => _AddList();
}

///-----------------------------------------
late var userData;
Future<void> getUserData() async {
  var user = FirebaseAuth.instance.currentUser;
  userData = user!.uid;
  //print(userData);
}

///-----------------------------------------

class _AddList extends State<AddList> {
  bool isPrivate = false;
  final CAtegoryNameController = TextEditingController();

  @override
  void dispose() {
    // Clean up the controller when the widget is removed from the
    // widget tree.
    CAtegoryNameController.dispose();
    super.dispose();
  }

  //const SendInstructionsView({Key? key}) : super(key: key);
  final formKey = GlobalKey<FormState>(); //key for form
  final _firestore = FirebaseFirestore.instance;
  String Category = '';
  List<dynamic> categoriesList = [];
  TextEditingController categoryController = TextEditingController();

  var selectCategory;
  bool buttonenabled = false;
  late String u;
  late final String documentId;
  String selectedValue = '';
  bool? isChecked = false;
  late String listt;
  late String category;

  @override
  Widget build(BuildContext context) {
    final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();
    getUserData();

    return Scaffold(
        appBar: AppBar(
          leadingWidth: 50,
          leading: IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: () {
              Util.routeToWidget(context, NavBar(tabs: 0));
            }, // home page
          ),
          actions: [
            Padding(
              padding: const EdgeInsets.only(right: 16.0),
            )
          ],
        ),
        body: Container(
          padding: const EdgeInsets.all(16.0),
          child: Form(
            key: formKey, //key for form
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Add List',
                  style: Theme.of(context).textTheme.headline4,
                ),
                SizedBox(
                  height: 10,
                ),
                Align(
                    alignment: Alignment.center,
                    child: Image.asset(
                      "assets/AddList.png",
                      height: 250,
                      width: 250,
                    )),
                SizedBox(
                  height: 16,
                ),

                //-----------------------List name-----------------------
                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  child: Text(
                    'List Name:',
                    style: Theme.of(context).textTheme.subtitle1,
                  ),
                ),
                SizedBox(
                  height: 3,
                ),
                TextFormField(
                    keyboardType: TextInputType.text,
                    controller: CAtegoryNameController,
                    decoration: InputDecoration(
                      hintText: 'Ex: SWE444',
                      contentPadding: EdgeInsets.symmetric(
                        vertical: 10,
                        horizontal: 10,
                      ),
                    ),
                    validator: (value) {
                      if (value!.isEmpty || value == null || value.trim() == '')
                        return "Please enter a name";
                      else
                        return null;
                    },
                    onChanged: (value) async {
                      listt = value;
                    },
                    style: Theme.of(context).textTheme.subtitle1),
                //-----------------------End of list name-----------------------

                SizedBox(
                  height: 8,
                ),

                //-----------------------Categorey-----------------------

                Padding(
                  padding: EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  child: Text(
                    'Categorey:',
                    style: Theme.of(context).textTheme.subtitle1,
                  ),
                ),

                SizedBox(
                  height: 3,
                ),

                DropdownButtonFormField2<String>(
                    scrollbarAlwaysShow: true,
                    itemHeight: 35,
                    style: TextStyle(
                        color: Color.fromRGBO(0, 0, 0, 1), fontSize: 15),
                    items: <String>['', '', '', '']
                        .map<DropdownMenuItem<String>>((String value) {
                      return DropdownMenuItem<String>(
                        value: value,
                        child: Text(
                          value,
                        ),
                      );
                    }).toList(),
                    onChanged: (categoreyValue) {
                      setState(() {
                        selectCategory = categoreyValue;
                      });
                    },
                    validator: (value) {
                      if (value == null)
                        return "Please choose category";
                      else
                        return null;
                    },
                    value: selectCategory,
                    isExpanded: true,
                    hint: new Text("Choose category",
                        style: TextStyle(fontSize: 15))),

                //-----------------------End of Categorey-----------------------

                CheckboxListTile(
                    activeColor: Color(0xff7b39ed),
                    //checkColor: Color(0xff7b39ed),
                    controlAffinity: ListTileControlAffinity.leading,
                    title: Text("Do you want it to be shared?"),
                    value: isChecked,
                    onChanged: (bool? value) {
                      setState(() {
                        isChecked = value;
                      });
                      print(isChecked);
                      // How did value change to true at this point?
                    }),

                Row(
                  children: [
                    Expanded(
                        child: ElevatedButton(
                      onPressed: () {
                        //navigate to check email view
                        if (formKey.currentState!.validate()) {
                          final snackBar =
                              SnackBar(content: Text("Added successfully"));
                          print(listt);
                          print(selectCategory);

                          CoolAlert.show(
                            context: context,
                            type: CoolAlertType.success,
                            text: "List Added successfuly!",
                            confirmBtnColor: const Color(0xff7b39ed),
                            onConfirmBtnTap: () => route(isChecked),
                          );
                        }
                      },
                      child: Text(
                        'Add',
                        style: TextStyle(fontSize: 20),
                      ),
                    )),
                  ],
                ),
              ],
            ),
          ),
        ));
  }

  void route(bool? isChecked) {
    if (isChecked == true)
      Util.routeToWidget(context, AddTask()); ///////////
    else
      Util.routeToWidget(context, AddTask());
    //print(text);
  }

  Widget _buildButton(
      {VoidCallback? onTap, required String text, Color? color}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10.0),
      child: MaterialButton(
        color: color,
        minWidth: double.infinity,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(30.0),
        ),
        onPressed: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 15.0),
          child: Text(
            text,
            style: TextStyle(
              color: Colors.white,
            ),
          ),
        ),
      ),
    );
  }
}

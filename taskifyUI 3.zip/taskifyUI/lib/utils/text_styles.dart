import 'package:flutter/material.dart';

import 'app_colors.dart';

class KTextStyle {
  static const headerTextStyle = TextStyle(
    color: AppColors.whiteshade,
    fontSize: 24,
    fontWeight: FontWeight.w700,
  );
}
